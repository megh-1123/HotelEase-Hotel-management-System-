'use client';

import { useEffect, useState } from 'react';
import styles from './Home.module.css';

type Article = {
  title: string;
  description: string;
  url: string;
  urlToImage?: string;
};

const categories = [
  'General',
  'Business',
  'Entertainment',
  'Health',
  'Science',
  'Sports',
  'Technology',
];

export default function HomePage() {
  const [articles, setArticles] = useState<Article[]>([]);
  const [page, setPage] = useState(1);

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('general');

  useEffect(() => {
    const fetchNews = async () => {
      const res = await fetch(
        `https://newsapi.org/v2/top-headlines?country=us&category=${selectedCategory}&page=${page}&pageSize=5&apiKey=93899f13c79e4e0cb38825f6aa0815e7`
      );
      const data = await res.json();
      setArticles(data.articles);
    };

    fetchNews();
  }, [selectedCategory, page]);

  const filteredArticles = articles.filter((article) =>
    article.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <main className={styles.container}>
      <h1 className={styles.heading}>Top Headlines</h1>

      {/* Categories */}
      <div className={styles.categoryContainer}>
        {categories.map((category) => (
          <button
            key={category}
            className={`${styles.categoryButton} ${
              selectedCategory === category.toLowerCase() ? styles.active : ''
            }`}
            onClick={() => {
              setSelectedCategory(category.toLowerCase());
              setPage(1); // reset to first page on category change
            }}
          >
            {category}
          </button>
        ))}
      </div>

      {/* Search */}
      <input
        type="text"
        placeholder="Search news..."
        className={styles.search}
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
      />

      {/* Articles */}
      {filteredArticles.map((article, index) => (
        <div key={index} className={styles.article}>
          {article.urlToImage && (
            <img src={article.urlToImage} alt="news image" className={styles.image} />
          )}

          <div>
            <h2>{article.title}</h2>
            <p>{article.description}</p>
            <a href={article.url} target="_blank" rel="noopener noreferrer">
              Read More
            </a>
          </div>
        </div>
      ))}

      {/* Pagination */}
      <div className={styles.pagination}>
        <button
          onClick={() => setPage((prev) => Math.max(prev - 1, 1))}
          disabled={page === 1}
        >
          Previous
        </button>
        <span>Page {page}</span>
        <button
          onClick={() => setPage((prev) => prev + 1)}
          disabled={articles.length < 5} // disables next if less than pageSize articles fetched
        >
          Next
        </button>
      </div>
    </main>
  );
}
