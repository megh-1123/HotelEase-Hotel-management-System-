// utils/fetchNews.ts
export async function fetchNews(category = "general", searchQuery = "", page = 1) {
  let url = "";

  if (searchQuery) {
    url = `https://newsapi.org/v2/everything?q=${encodeURIComponent(searchQuery)}&page=${page}&pageSize=10&apiKey=93899f13c79e4e0cb38825f6aa0815e7`;
  } else {
    url = `https://newsapi.org/v2/top-headlines?country=us&category=${category}&page=${page}&pageSize=10&apiKey=93899f13c79e4e0cb38825f6aa0815e7`;
  }

  const res = await fetch(url);
  const data = await res.json();
  return data.articles;
}
