// components/CategoryList.tsx
'use client';

import React from 'react';
import styles from './CategoryList.module.css';

const categories = ["General", "Business", "Entertainment", "Health", "Science", "Sports", "Technology"];


export default function CategoryList() {
  return (
    <div className={styles.container}>
      {categories.map((category) => (
        <button
          key={category}
          className={styles.category}
          onClick={() => {
            window.location.href = `/?category=${category.toLowerCase()}`;
          }}
        >
          {category}
        </button>
      ))}
    </div>
  );
}
